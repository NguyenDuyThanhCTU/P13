import Contact from "@components/client/Contact/Contact";
import React from "react";

const ContactPage = () => {
  return (
    <>
      <Contact />
    </>
  );
};

export default ContactPage;
