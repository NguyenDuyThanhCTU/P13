import ProductDetail from "@components/client/Product/ProductDetail";
import React from "react";

const ProductDetailPage = () => {
  return (
    <>
      <ProductDetail />
    </>
  );
};

export default ProductDetailPage;
