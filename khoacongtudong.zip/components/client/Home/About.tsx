import React from "react";

const About = () => {
  return (
    <div>
      <div className="w-[1460px] mx-auto grid grid-cols-2 ">
        <div className="relative">
          <img
            src="https://file.hstatic.net/200000235187/file/chungtoi_9eccf562e67b44b189de6a5f30e4215d.jpg"
            alt=""
          />
        </div>
        <div></div>
      </div>
    </div>
  );
};

export default About;
